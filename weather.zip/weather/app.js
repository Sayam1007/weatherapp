window.addEventListener('load',() => {
    
    let long;
    let lat;
    let temperaturedescription = document.querySelector('.temperature-description');
    let temperaturedegree = document.querySelector('.temperature-degree');
    let locationtimezone = document.querySelector('.location-timezone');
    let temperatures=document.querySelector('.temperature');
    const temperatureSpan = document.querySelector('.temperature span');
    
    if(navigator.geolocation){
        navigator.geolocation.getCurrentPosition(position =>{
            
     long = position.coords.longitude;
     lat = position.coords.latitude;
      
     const proxy = 'https //cors-anywhere.herokuapp.com ';        
            
     const api = `https://api.openweathermap.org/data/2.5/onecall?lat=28.6139&lon=77.2090&exclude=minutely&appid=c7d8d127a78bf55a2ecf6b775b210d1f`;
        
        fetch(api).then(response =>{
            
            return response.json();
        })
    .then(data =>{console.log(data);
                  
                  const{temp,weather,icon} = data.current;
        
                  temperaturedegree.textContent=temp;
                  temperaturedescription.textContent=weather[0].description;
                  locationtimezone.textContent=data.timezone; 
                  let cel = temp-273.15;
                 
             
               
                  
              
                 
    temperatures.addEventListener('click', () =>{
        if(temperatureSpan.textContent === "Kelvin"){
            
            
            temperatureSpan.textContent = "Celsius";
            temperaturedegree.textContent = Math.floor(cel);
            
        }else{
            temperatureSpan.textContent = "Kelvin";
            temperaturedegree.textContent=temp;
        }
    }
                                       
                                       
                                       
                                       
                                       
                                       )});
    });
                        
    }
    
  
  
});